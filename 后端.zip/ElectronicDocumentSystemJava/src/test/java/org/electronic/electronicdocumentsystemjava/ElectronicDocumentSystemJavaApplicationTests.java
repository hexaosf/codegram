package org.electronic.electronicdocumentsystemjava;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicDocumentSystemJavaApplicationTests {

}
