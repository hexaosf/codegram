package org.electronic.electronicdocumentsystemjava.controller;

import cn.hutool.core.util.HexUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.NonNull;
import org.bouncycastle.util.encoders.Hex;
import org.electronic.electronicdocumentsystemjava.entity.File;
import org.electronic.electronicdocumentsystemjava.entity.SM4Key;
import org.electronic.electronicdocumentsystemjava.entity.User;
import org.electronic.electronicdocumentsystemjava.form.Sm2UploadForm;
import org.electronic.electronicdocumentsystemjava.form.Sm3UploadForm;
import org.electronic.electronicdocumentsystemjava.form.Sm4UploadForm;
import org.electronic.electronicdocumentsystemjava.response.JsonResponse;
import org.electronic.electronicdocumentsystemjava.service.IFileService;
import org.electronic.electronicdocumentsystemjava.service.ISM4Service;
import org.electronic.electronicdocumentsystemjava.service.IUserService;
import org.electronic.electronicdocumentsystemjava.util.CipherUtil;
import org.electronic.electronicdocumentsystemjava.util.FileUtils;
import org.electronic.electronicdocumentsystemjava.util.RSAManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.electronic.electronicdocumentsystemjava.response.ResponseCode.*;


@RestController
@RequestMapping("/file")
public class FileController {

    private static final String SM3_KEY = "";
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    private final IUserService userService;

    private final IFileService fileService;

    private final ISM4Service sm4Service;

    private final RSAManager rsaManager;

    public FileController(IUserService userService, IFileService fileService, ISM4Service sm4Service, RSAManager rsaManager) {
        this.userService = userService;
        this.fileService = fileService;
        this.sm4Service = sm4Service;
        this.rsaManager = rsaManager;
    }

    @Transactional
    @PostMapping("/test")
    public JsonResponse<User> register(@NonNull HttpServletRequest request) {
        User user = (User) request.getAttribute("user");
        LOGGER.info("访问了测试");
        return new JsonResponse<>(SUCCESS, user);
    }

    @GetMapping("/file_list")
    public JsonResponse<List<File>> getFileList() {
        List<File> fileList = fileService.getFileAll();
        return new JsonResponse<>(SUCCESS, fileList);
    }

    @DeleteMapping("/delete/{fileId}")
    public JsonResponse<Boolean> deleteFile(@PathVariable("fileId") String fileId, @NonNull HttpServletRequest request) {
        User user = (User) request.getAttribute("user");
        File file = fileService.getById(fileId);
        if (!Objects.equals(file.getUserId(), user.getId())) {
            return new JsonResponse<>(NOT_THE_OWNER_OF_THE_FILE);
        }
        file.setIsDel(true);
        fileService.updateById(file);
        return new JsonResponse<>(SUCCESS);
    }

    @Transactional
    @PostMapping("/sm2/upload")
    public JsonResponse<String> sm2Upload(@Valid @RequestBody Sm2UploadForm form, BindingResult result, @NonNull HttpServletRequest request) throws Exception {
        if (result.hasErrors() || !userService.existsByUsername(form.getTargetUsername())) {
            return new JsonResponse<>(THE_PARAMETER_IS_ABNORMAL);
        }
        User targetUser = userService.getByUsername(form.getTargetUsername());
        User user = (User) request.getAttribute("user");
        File file = new File();
        file.setFilename(form.getFilename());
        file.setSize(form.getSize());
        file.setEncryption("sm2");
        file.setUserId(user.getId());
        file.setSm2UserId(targetUser.getId());
        fileService.save(file);
        byte[] decrypt = CipherUtil.sm2Decrypt(form.getContent(), targetUser.getF2bPri());
        String s = new String(decrypt);
        FileUtils.saveFile(Hex.decode(s), file.getId());
        return new JsonResponse<>(SUCCESS);
    }

    @Transactional
    @GetMapping("/sm2/{fileId}")
    public JsonResponse<String> sm2Download(@PathVariable("fileId") String fileId, @NonNull HttpServletRequest request) throws Exception {
        File file = fileService.getById(fileId);
        User user = userService.getById(file.getSm2UserId());
        byte[] content = FileUtils.readFile(file.getId());
        String hexStr = HexUtil.encodeHexStr(content);
        byte[] encrypt = CipherUtil.sm2Encrypt(hexStr.getBytes(), user.getB2fPri(), user.getB2fPub());
        String encodeHexStr = HexUtil.encodeHexStr(encrypt);
        return new JsonResponse<>(SUCCESS, encodeHexStr);
    }

    @Transactional
    @PostMapping("/sm3/upload")
    public JsonResponse<String> sm3Upload(@Valid @RequestBody Sm3UploadForm form, BindingResult result, @NonNull HttpServletRequest request) throws IOException {
        if (result.hasErrors()) {
            return new JsonResponse<>(THE_PARAMETER_IS_ABNORMAL);
        }
        User user = (User) request.getAttribute("user");
        String enContent = CipherUtil.sm3Digest(form.getContent().getBytes());
        if (!enContent.equals(form.getEnContent())) {
            return new JsonResponse<>(THE_FILE_HAS_BEEN_TAMPERED_WITH);
        }
        File file = new File();
        file.setFilename(form.getFilename());
        file.setSize(form.getSize());
        file.setEncryption("sm3");
        file.setUserId(user.getId());
        file.setType(form.getType());
        fileService.save(file);
        FileUtils.saveFile(Hex.decode(form.getContent()), file.getId());
        return new JsonResponse<>(SUCCESS);
    }

    @Transactional
    @GetMapping("/sm3/{fileId}")
    public JsonResponse<Map<String, String>> sm3Download(@PathVariable("fileId") String fileId, @NonNull HttpServletRequest request) throws IOException {
        File file = fileService.getById(fileId);
        if (file == null) {
            return new JsonResponse<>(THE_FILE_DOES_NOT_EXIST);
        }
        byte[] bytes = FileUtils.readFile(file.getId());
        String hexContent = Hex.toHexString(bytes);
        String enContent = CipherUtil.sm3Digest(hexContent.getBytes());
        Map<String, String> map = new HashMap<>();
        map.put("enContent", enContent);
        map.put("hexContent", hexContent);
        return new JsonResponse<>(SUCCESS, map);
    }


    @Transactional
    @PostMapping("/sm4/upload")
    public JsonResponse<String> sm4Upload(@Valid @RequestBody Sm4UploadForm form, BindingResult result, @NonNull HttpServletRequest request) throws Exception {
        if (result.hasErrors()) {
            return new JsonResponse<>(THE_PARAMETER_IS_ABNORMAL);
        }
        String sm4Key;
        try {
            sm4Key = rsaManager.decrypt(form.getSm4Key());
        } catch (Exception e) {
            return new JsonResponse<>(THE_PARAMETER_IS_ABNORMAL);
        }
        SM4Key key = sm4Service.getByKey(sm4Key);
        User user = (User) request.getAttribute("user");
        File file = new File();
        file.setFilename(form.getFilename());
        file.setSize(form.getSize());
        file.setEncryption("sm4");
        file.setUserId(user.getId());
        file.setType(form.getType());
        file.setSm4Id(key.getId());
        fileService.save(file);
        byte[] decrypted = CipherUtil.sm4Decrypt(sm4Key, Hex.decode(form.getContent()));
        String s = new String(decrypted);
        FileUtils.saveFile(Hex.decode(s), file.getId());
        return new JsonResponse<>(SUCCESS);
    }

    @Transactional
    @GetMapping("/sm4/{fileId}")
    public JsonResponse<String> sm4Download(@PathVariable("fileId") String fileId, @NonNull HttpServletRequest request) throws Exception {
        File file = fileService.getById(fileId);
        if (file == null || file.getSm4Id() == null) {
            return new JsonResponse<>(THE_FILE_DOES_NOT_EXIST);
        }
        SM4Key sm4Key = sm4Service.getById(file.getSm4Id());
        byte[] bytes = FileUtils.readFile(file.getId());
        String s = Hex.toHexString(bytes);
        byte[] encrypt = CipherUtil.sm4Encrypt(sm4Key.getK(), s.getBytes());
        String hexString = Hex.toHexString(encrypt);
        return new JsonResponse<>(SUCCESS, hexString);
    }
}
