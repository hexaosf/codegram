package org.electronic.electronicdocumentsystemjava.form;

import lombok.Data;
import lombok.NonNull;

@Data
public class Sm4UploadForm {
    @NonNull
    private String filename;
    @NonNull
    private Integer size;
    @NonNull
    private String content;
    @NonNull
    private String sm4Key;
    @NonNull
    private String type;
}