package org.electronic.electronicdocumentsystemjava.config;

import org.electronic.electronicdocumentsystemjava.interceptor.JwtHeaderInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final JwtHeaderInterceptor jwtHeaderInterceptor;

    public WebConfig(JwtHeaderInterceptor jwtHeaderInterceptor) {
        this.jwtHeaderInterceptor = jwtHeaderInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration registration = registry.addInterceptor(jwtHeaderInterceptor);
        registration.addPathPatterns("/file/**");
        registration.addPathPatterns("/key/**");
        registration.addPathPatterns("/user/get_user_list");
        registration.addPathPatterns("/user/get_sm2_pub_key");
        registration.addPathPatterns("/user/get_sm2_pri_key");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                //是否发送Cookie
                .allowCredentials(false)
                //放行哪些原始域
                .allowedOrigins(CorsConfiguration.ALL)
                .allowedMethods(new String[]{"GET", "POST", "PUT", "DELETE"})
                .allowedHeaders(CorsConfiguration.ALL)
                .exposedHeaders(CorsConfiguration.ALL);
    }
}