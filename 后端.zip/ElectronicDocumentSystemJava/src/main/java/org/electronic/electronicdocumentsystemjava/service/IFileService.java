package org.electronic.electronicdocumentsystemjava.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.apache.ibatis.annotations.Param;
import org.electronic.electronicdocumentsystemjava.entity.File;

import java.util.List;

public interface IFileService extends IService<File> {
    List<File> getFileAll();
    List<File> getFileAll(Integer limit, Integer office);
}
