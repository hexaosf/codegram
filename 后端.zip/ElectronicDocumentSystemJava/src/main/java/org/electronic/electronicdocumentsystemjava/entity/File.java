package org.electronic.electronicdocumentsystemjava.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@TableName(value = "file", excludeProperty = "user")
@ApiModel(value = "文件对象", description = "上传的文件对象")
public class File implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    private String id;

    @Setter
    @ApiModelProperty("文件名")
    private String filename;

    @ApiModelProperty("文件大小")
    private Integer size;

    @ApiModelProperty("使用的加密方式")
    private String encryption;

    @JsonIgnore
    @TableField
    @ApiModelProperty("上传用户id")
    private Integer userId;

    @ApiModelProperty("文件类型")
    private String type;

    @ApiModelProperty("使用的sm4的id")
    private Integer sm4Id;

    @ApiModelProperty("使用的sm2的公钥用户id")
    private Integer sm2UserId;

    @JsonIgnore
    @ApiModelProperty("是否删除")
    private Boolean isDel;

    @ApiModelProperty("上传时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm", timezone = "Asia/Shanghai")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime uploadTime;

    @TableField(exist = false)
    private String username;

    @TableField(exist = false)
    private User user;

    @Override
    public String toString() {
        return "File{" +
                "id='" + id + '\'' +
                ", filename='" + filename + '\'' +
                ", size=" + size +
                ", encryption='" + encryption + '\'' +
                ", userId=" + userId +
                ", isDel=" + isDel +
                '}';
    }

    public LocalDateTime getUploadTime() {
        if (uploadTime == null){
            return LocalDateTime.now();
        }
        return uploadTime;
    }
}
