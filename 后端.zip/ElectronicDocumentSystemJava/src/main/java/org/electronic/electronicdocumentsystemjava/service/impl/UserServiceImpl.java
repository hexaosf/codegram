package org.electronic.electronicdocumentsystemjava.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.electronic.electronicdocumentsystemjava.dao.UserMapper;
import org.electronic.electronicdocumentsystemjava.entity.User;
import org.electronic.electronicdocumentsystemjava.service.IUserService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    private final UserMapper userMapper;

    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public User getByUsername(String username) {
        return userMapper.getByUsername(username);
    }

    @Override
    public boolean existsByUsername(String username) {
        User user = getByUsername(username);
        return user != null;
    }

    @Override
    public List<String> getUsernameList(Integer limit, Integer office) {
        return userMapper.getUsernameList(limit, office);
    }

    @Override
    public List<String> getUsernameList() {
        return getUsernameList(1000, 0);
    }
}
