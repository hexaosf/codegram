package org.electronic.electronicdocumentsystemjava.form;

import lombok.Data;
import lombok.NonNull;

@Data
public class Sm2UploadForm {
    @NonNull
    private String filename;
    @NonNull
    private Integer size;
    @NonNull
    private String content;
    @NonNull
    private String targetUsername;
}