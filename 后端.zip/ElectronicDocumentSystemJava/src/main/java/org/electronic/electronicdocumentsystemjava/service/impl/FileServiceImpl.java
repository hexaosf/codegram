package org.electronic.electronicdocumentsystemjava.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.electronic.electronicdocumentsystemjava.dao.FileMapper;
import org.electronic.electronicdocumentsystemjava.entity.File;
import org.electronic.electronicdocumentsystemjava.service.IFileService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FileServiceImpl extends ServiceImpl<FileMapper, File> implements IFileService {
    private final FileMapper fileMapper;

    public FileServiceImpl(FileMapper fileMapper) {
        this.fileMapper = fileMapper;
    }

    @Override
    public List<File> getFileAll() {
        return getFileAll(1000, 0);
    }

    @Override
    public List<File> getFileAll(Integer limit, Integer office) {
        return fileMapper.getFileAll(limit, office);
    }
}
