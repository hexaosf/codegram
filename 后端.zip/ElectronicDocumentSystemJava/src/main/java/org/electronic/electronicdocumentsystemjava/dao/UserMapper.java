package org.electronic.electronicdocumentsystemjava.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.electronic.electronicdocumentsystemjava.entity.User;

import java.util.List;


public interface UserMapper extends BaseMapper<User> {
    @Select("SELECT * FROM user WHERE username = #{username}")
    User getByUsername(@Param("username") String username);

    @Select("SELECT username FROM user LIMIT #{limit} OFFSET #{office}")
    List<String> getUsernameList(@Param("limit") Integer limit, @Param("office") Integer office);
}
