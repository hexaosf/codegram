package org.electronic.electronicdocumentsystemjava.form;

import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NonNull;

@Data
public class LoginForm {
    @NonNull
    @Pattern(regexp = "^[a-zA-Z0-9]{4,8}$", message = "用户名只能包含字母和数字,并且长度要在4-8位")
    private String username;
    @NonNull
    @Pattern(regexp = "^[a-zA-Z0-9\\/\\+]+\\=\\=$", message = "密码格式不正确")
    private String password;
}
