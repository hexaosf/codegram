package org.electronic.electronicdocumentsystemjava.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.electronic.electronicdocumentsystemjava.entity.User;

import java.util.List;


public interface IUserService extends IService<User> {
    User getByUsername(String username);

    boolean existsByUsername(String username);

    List<String> getUsernameList();

    List<String> getUsernameList(Integer limit, Integer office);
}
