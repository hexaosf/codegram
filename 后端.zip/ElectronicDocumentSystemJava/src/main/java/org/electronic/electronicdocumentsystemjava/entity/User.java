package org.electronic.electronicdocumentsystemjava.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Setter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;


@Data
@ApiModel(value = "User对象", description = "用户表")
public class User implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @Setter
    @ApiModelProperty("用户名")
    private String username;

    @JsonIgnore
    @ApiModelProperty("密码")
    private String password;

    @JsonIgnore
    @ApiModelProperty("后端传前端sm2公钥")
    private String b2fPub;

    @JsonIgnore
    @ApiModelProperty("后端传前端sm2私钥")
    private String b2fPri;

    @JsonIgnore
    @ApiModelProperty("前端传后sm2公钥")
    private String f2bPub;

    @JsonIgnore
    @ApiModelProperty("前端传后端sm2私钥")
    private String f2bPri;

    @JsonIgnore
    @ApiModelProperty("是否删除")
    private Boolean isDel;

    @TableField(exist = false)
    private List<File> files;

    public String hashPassword(String password) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        return encoder.encode(password);
    }

    public void setHashPassword(String password) {
        this.password = hashPassword(password);
    }

    public boolean checkPassword(String password) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        return encoder.matches(password, this.password);
    }

    @Override
    public String toString() {
        return "User{" +
                "id = " + id +
                ", username = " + username +
                ", password = " + password +
                ", isDel = " + isDel +
                "}";
    }
}
