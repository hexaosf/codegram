package org.electronic.electronicdocumentsystemjava.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.electronic.electronicdocumentsystemjava.entity.SM4Key;
import org.electronic.electronicdocumentsystemjava.entity.User;

import java.util.List;

public interface SM4Mapper extends BaseMapper<SM4Key> {
    @Select("SELECT * FROM sm4_key WHERE sm4_key.k = #{key}")
    SM4Key getByKey(@Param("key") String key);
    @Select("SELECT `k` FROM sm4_key LIMIT #{limit} OFFSET #{office}")
    List<String> getKeyAll(@Param("limit") Integer limit, @Param("office") Integer office);
}
