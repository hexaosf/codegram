package org.electronic.electronicdocumentsystemjava.response;


import lombok.Getter;

@Getter
public enum ResponseCode {
    SUCCESS(0, "success"),
    USER_IS_EXIST(1001, "The user already exists"),
    USER_IS_NOT_EXIST(1002, "The user does not exist"),
    WRONG_USERNAME_OR_PASSWORD(1003, "Wrong username or password"),
    THE_INPUT_FORMAT_IS_INCORRECT(1003, "The input format is incorrect"),
    THE_PARAMETER_IS_ABNORMAL(2001, "The parameter is incorrect"),
    THE_VOUCHER_HAS_EXPIRED(3001, "The voucher has expired"),
    THE_FILE_SIZE_EXCEEDS_THE_LIMIT(4001, "The file size exceeds the limit"),
    THE_FILE_HAS_BEEN_TAMPERED_WITH(4002, "The file has been tampered with"),
    THE_FILE_DOES_NOT_EXIST(4003, "The file does not exist"),
    NOT_THE_OWNER_OF_THE_FILE(4004, "Not the owner of the file"),
    SERVER_ERROR(5000, "Server error"),
    ;
    private final int code;
    private final String description;

    ResponseCode(int code, String description) {
        this.code = code;
        this.description = description;
    }

}
