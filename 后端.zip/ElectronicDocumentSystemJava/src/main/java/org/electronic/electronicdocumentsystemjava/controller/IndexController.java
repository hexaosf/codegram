package org.electronic.electronicdocumentsystemjava.controller;

import org.electronic.electronicdocumentsystemjava.response.JsonResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 访问主页
 */
@RestController
public class IndexController {

    @GetMapping("/")
    public JsonResponse getUser() {
        return new JsonResponse();
    }
}
