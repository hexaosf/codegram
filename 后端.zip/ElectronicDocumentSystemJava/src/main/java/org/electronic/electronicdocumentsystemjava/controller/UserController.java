package org.electronic.electronicdocumentsystemjava.controller;

import cn.hutool.core.util.HexUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.SM2;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.NonNull;
import org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;
import org.electronic.electronicdocumentsystemjava.entity.User;
import org.electronic.electronicdocumentsystemjava.form.LoginForm;
import org.electronic.electronicdocumentsystemjava.form.RegisterForm;
import org.electronic.electronicdocumentsystemjava.response.JsonResponse;
import org.electronic.electronicdocumentsystemjava.service.IUserService;
import org.electronic.electronicdocumentsystemjava.util.CipherUtil;
import org.electronic.electronicdocumentsystemjava.util.JwtManager;
import org.electronic.electronicdocumentsystemjava.util.RSAManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.KeyPair;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.electronic.electronicdocumentsystemjava.response.ResponseCode.*;

@RestController
@RequestMapping("/user")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
    private final IUserService userService;
    private final JwtManager jwtManager;
    private final RSAManager rsaManager;

    public UserController(IUserService userService, JwtManager jwtManager, RSAManager rsaManager) {
        this.userService = userService;
        this.jwtManager = jwtManager;
        this.rsaManager = rsaManager;
    }

    @Transactional
    @PostMapping("/register")
    public JsonResponse<String> register(@Valid @RequestBody RegisterForm form, BindingResult result) {
        if (result.hasErrors()) {
            return new JsonResponse<>(THE_INPUT_FORMAT_IS_INCORRECT);
        }
        if (userService.existsByUsername(form.getUsername())) {
            return new JsonResponse<>(THE_INPUT_FORMAT_IS_INCORRECT);
        }
        String password = null;
        Map<String, String> b2fKeyPair = null;
        Map<String, String> f2bKeyPair = null;
        try {
            password = rsaManager.decrypt(form.getPassword());
            b2fKeyPair = CipherUtil.getKeyPair();
            f2bKeyPair = CipherUtil.getKeyPair();
        } catch (Exception e) {
            return new JsonResponse<>(SERVER_ERROR);
        }
        User user = new User();
        user.setUsername(form.getUsername());
        user.setHashPassword(password);
        user.setB2fPub(b2fKeyPair.get("public"));
        user.setB2fPri(b2fKeyPair.get("private"));
        user.setF2bPub(f2bKeyPair.get("public"));
        user.setF2bPri(f2bKeyPair.get("private"));
        userService.save(user);
        return new JsonResponse<>(SUCCESS);
    }

    @PostMapping("/login")
    public JsonResponse<String> login(@Valid @RequestBody LoginForm form, BindingResult result) {
        if (result.hasErrors() || !userService.existsByUsername(form.getUsername())) {
            return new JsonResponse<>(WRONG_USERNAME_OR_PASSWORD);
        }
        String password = null;
        try {
            password = rsaManager.decrypt(form.getPassword());
        } catch (Exception e) {
            return new JsonResponse<>(THE_INPUT_FORMAT_IS_INCORRECT);
        }
        User user = userService.getByUsername(form.getUsername());
        if (!user.checkPassword(password)) {
            return new JsonResponse<>(WRONG_USERNAME_OR_PASSWORD);
        }
        String jwtToken = jwtManager.encrypt(user);
        return new JsonResponse<>(SUCCESS, jwtToken);
    }

    @GetMapping("/get_user_list")
    public JsonResponse<List<String>> getUserList() {
        List<String> userList = userService.getUsernameList();
        return new JsonResponse<>(SUCCESS, userList);
    }

    @GetMapping("/get_sm2_pub_key")
    public JsonResponse<String> getUserSM2PubKey(@RequestParam String username) throws Exception {
        User user = userService.getByUsername(username);
        if (user == null) {
            return new JsonResponse<>(USER_IS_NOT_EXIST);
        }
        String encrypt = rsaManager.encrypt(user.getF2bPub());
        return new JsonResponse<>(SUCCESS, encrypt);
    }

    @GetMapping("/get_sm2_pri_key")
    public JsonResponse<String> getUserSM2PriKey(@NonNull HttpServletRequest request) throws Exception {
        User user = (User) request.getAttribute("user");
        if (user == null) {
            return new JsonResponse<>(USER_IS_NOT_EXIST);
        }
        String pri = user.getB2fPri();
        List<String> stringList = splitString(pri, 20);
        String encrypt = encryptAndJoin(stringList);
        return new JsonResponse<>(SUCCESS, encrypt);
    }

    public static List<String> splitString(String text, int n) {
        List<String> result = new ArrayList<>();
        int length = text.length();
        for (int i = 0; i < length; i += n) {
            result.add(text.substring(i, Math.min(length, i + n)));
        }
        return result;
    }

    public String encryptAndJoin(List<String> parts) throws Exception {
        StringBuilder encrypted = new StringBuilder();
        for (String part : parts) {
            String encryptedPart = rsaManager.encrypt(part); // 加密每一段
            encrypted.append(encryptedPart).append("+~~+"); // 拼接加密结果
        }
        String result = encrypted.toString();
        // 移除最后一个"+"
        if (result.endsWith("+~~+")) {
            result = result.substring(0, result.length() - 4);
        }
        return result;
    }
}
