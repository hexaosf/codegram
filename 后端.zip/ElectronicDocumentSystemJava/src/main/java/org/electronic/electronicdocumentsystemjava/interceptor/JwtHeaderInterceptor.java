package org.electronic.electronicdocumentsystemjava.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import org.electronic.electronicdocumentsystemjava.controller.UserController;
import org.electronic.electronicdocumentsystemjava.entity.User;
import org.electronic.electronicdocumentsystemjava.util.JwtManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class JwtHeaderInterceptor implements HandlerInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
    private final JwtManager jwtManager;

    public JwtHeaderInterceptor(JwtManager jwtManager) {
        this.jwtManager = jwtManager;
    }

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler) throws Exception {
        if (HttpMethod.OPTIONS.toString().equals(request.getMethod())) {
            LOGGER.info("OPTIONS请求，放行");
            return true;
        }
        String authorizationHeaderValue = request.getHeader("Authorization");
        if (authorizationHeaderValue == null || !authorizationHeaderValue.startsWith("bearer ")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not allowed");
            return false;
        }
        String value = authorizationHeaderValue.substring(7);
        User user = jwtManager.decrypt(value);
        if (user == null) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not allowed");
            return false;
        }
        request.setAttribute("user", user);
        return true;
    }
}
