package org.electronic.electronicdocumentsystemjava.controller;

import org.electronic.electronicdocumentsystemjava.response.JsonResponse;
import org.electronic.electronicdocumentsystemjava.service.ISM4Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.electronic.electronicdocumentsystemjava.response.ResponseCode.SUCCESS;

@RestController
@RequestMapping("/key")
public class KeyController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    private final ISM4Service ism4Service;

    public KeyController(ISM4Service ism4Service) {
        this.ism4Service = ism4Service;
    }

    @GetMapping("/sm4_list")
    public JsonResponse<List<String>> getSm4List() {
        List<String> keyAll = ism4Service.getKeyAll();
        return new JsonResponse<>(SUCCESS, keyAll);
    }
}
