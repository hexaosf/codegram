package org.electronic.electronicdocumentsystemjava.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
@MapperScan("org.electronic.**.dao")
@Configuration
public class MybatisPlusConfiguration {
}
