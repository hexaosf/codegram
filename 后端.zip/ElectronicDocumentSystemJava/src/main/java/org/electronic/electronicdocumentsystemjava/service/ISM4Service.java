package org.electronic.electronicdocumentsystemjava.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.apache.ibatis.annotations.Param;
import org.electronic.electronicdocumentsystemjava.entity.SM4Key;

import java.util.List;

public interface ISM4Service extends IService<SM4Key> {
    SM4Key getByKey(String k);
    List<String> getKeyAll();
    List<String> getKeyAll(Integer limit, Integer office);
}
