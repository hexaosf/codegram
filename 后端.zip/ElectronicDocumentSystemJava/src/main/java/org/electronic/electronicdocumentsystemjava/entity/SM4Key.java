package org.electronic.electronicdocumentsystemjava.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

@Data
@TableName("sm4_key")
@ApiModel(value = "sm4密钥对象", description = "sm4密钥")
public class SM4Key implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("密钥")
    private String k;

    @JsonIgnore
    @ApiModelProperty("是否删除")
    private Boolean isDel;

    @Override
    public String toString() {
        return "SM4Key{" +
                "id = " + id +
                ", key = " + k +
                ", isDel = " + isDel +
                "}";
    }
}
