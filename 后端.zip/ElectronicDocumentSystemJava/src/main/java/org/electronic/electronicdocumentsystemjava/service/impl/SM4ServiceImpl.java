package org.electronic.electronicdocumentsystemjava.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.bouncycastle.jcajce.provider.symmetric.SM4;
import org.electronic.electronicdocumentsystemjava.dao.SM4Mapper;
import org.electronic.electronicdocumentsystemjava.dao.UserMapper;
import org.electronic.electronicdocumentsystemjava.entity.SM4Key;
import org.electronic.electronicdocumentsystemjava.service.ISM4Service;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SM4ServiceImpl extends ServiceImpl<SM4Mapper, SM4Key> implements ISM4Service {
    private final SM4Mapper sm4Mapper;

    public SM4ServiceImpl(SM4Mapper sm4Mapper) {
        this.sm4Mapper = sm4Mapper;
    }

    @Override
    public SM4Key getByKey(String k) {
        return sm4Mapper.getByKey(k);
    }

    @Override
    public List<String> getKeyAll(){
        return getKeyAll(1000, 0);
    }

    @Override
    public List<String> getKeyAll(Integer limit, Integer office){
        return sm4Mapper.getKeyAll(limit, office);
    }
}
