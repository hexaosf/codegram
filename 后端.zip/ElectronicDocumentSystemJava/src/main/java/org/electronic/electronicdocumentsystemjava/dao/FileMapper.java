package org.electronic.electronicdocumentsystemjava.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.electronic.electronicdocumentsystemjava.entity.File;

import java.util.List;

public interface FileMapper extends BaseMapper<File> {
    @Select("SELECT file.*, user.username FROM file, user where user.id = file.user_id AND file.is_del = 0 LIMIT #{limit} OFFSET #{office}")
    List<File> getFileAll(@Param("limit") Integer limit, @Param("office") Integer office);
}
