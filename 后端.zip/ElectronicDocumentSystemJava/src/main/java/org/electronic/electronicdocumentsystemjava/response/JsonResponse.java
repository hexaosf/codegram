package org.electronic.electronicdocumentsystemjava.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * json响应类
 */
public class JsonResponse<T> {
    /**
     * 响应描述
     */
    @JsonProperty("msg")
    private String msg;

    /**
     * 响应码
     */
    @JsonProperty("code")
    private int code;

    /**
     * 响应内容
     */
    @JsonProperty("data")
    private T data;

    public JsonResponse() {
        this.msg = "ok";
        this.code = 0;
        this.data = null;
    }

    public JsonResponse(T data) {
        this.msg = "ok";
        this.code = 0;
        this.data = data;
    }

    public JsonResponse(ResponseCode code) {
        this.msg = code.getDescription();
        this.code = code.getCode();
        this.data = null;
    }

    public JsonResponse(ResponseCode code, T data) {
        this.msg = code.getDescription();
        this.code = code.getCode();
        this.data = data;
    }

    public JsonResponse(String msg, ResponseCode code, T data) {
        this.msg = msg;
        this.code = code.getCode();
        this.data = data;
    }

    public JsonResponse(String msg, int code, T data) {
        this.msg = msg;
        this.code = code;
        this.data = data;
    }
}
