package org.electronic.electronicdocumentsystemjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = {
        "org.electronic.**.config",
        "org.electronic.**.controller",
        "org.electronic.**.dao",
        "org.electronic.**.entity",
        "org.electronic.**.exception",
        "org.electronic.**.interceptor",
        "org.electronic.**.response",
        "org.electronic.**.service",
        "org.electronic.**.service.impl",
        "org.electronic.**.handler",
        "org.electronic.**.filter",
        "org.electronic.**.util"
})
@SpringBootApplication
public class ElectronicDocumentSystemJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElectronicDocumentSystemJavaApplication.class, args);
    }

}
