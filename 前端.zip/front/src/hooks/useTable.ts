const useTable = () => {};

export default useTable;
