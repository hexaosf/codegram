const Menu23 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu23 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu23;
