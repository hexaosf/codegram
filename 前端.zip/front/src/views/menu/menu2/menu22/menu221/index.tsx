const Menu221 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu221 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu221;
