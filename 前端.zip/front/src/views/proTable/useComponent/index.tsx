import "./index.less";

const UseComponent = () => {
	return (
		<div className="card content-box">
			<span className="text">UseComponent 🍓🍇🍈🍉</span>
		</div>
	);
};

export default UseComponent;
