const Gitee = () => {
	return (
		<div className="card content-box">
			<span className="text">
				Gitee 仓库：
				<a href="https://gitee.com/laramie/Hooks-Admin" target="_blank" rel="noreferrer">
					https://gitee.com/laramie/Hooks-Admin
				</a>{" "}
				🍒🍉🍊
			</span>
		</div>
	);
};

export default Gitee;
