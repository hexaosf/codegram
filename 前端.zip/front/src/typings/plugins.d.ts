declare module "qs";
declare module "nprogress";
declare module "js-md5";
declare module "react-transition-group";
